-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2023 at 10:54 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitalsolutionhag`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `ID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Body` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`ID`, `Title`, `Body`) VALUES
(5, 'Hot weather advice', '<p><strong><span style=\"font-size: 24px;\">Introduction</span></strong></p><p>Hot weather can cause heat exhaustion in people and animals. Also, bacteria on food and rubbish develop more quickly in the heat. Find out how to stay safe around the home in hot weather, including keeping cool and taking extra care with food and waste.</p><p><br></p><p><strong><span style=\"font-size: 24px;\">Looking after your health in hot weather</span></strong></p><p>Summer temperatures can be a risk to health. It is important to make sure you and those you care for are suitably hydrated. In a heatwave, you may get dehydrated and your body may overheat. This can lead to heat exhaustion or heatstroke, which both need urgent treatment. Heatstroke can cause: serious damage to your body or even death.</p><ul><li>Heat exhaustion and heatstroke</li><li>Symptoms of heat exhaustion include:</li><li>headache</li><li>dizziness</li><li>nausea and vomiting</li><li>muscle weakness or cramps</li><li>pale skin</li><li>high temperature</li></ul><p>If you think you have heat exhaustion, you should move somewhere cool and drink plenty of water. If you can, take a lukewarm shower or sponge yourself down with cold water. If heat exhaustion is untreated, you could develop heatstroke. Heatstroke can also occur suddenly and without any warning. Symptoms of heatstroke include:</p><ul><li>headache</li><li>nausea</li><li>intense thirst</li><li>sleepiness</li><li>hot, red and dry skin</li><li>a sudden rise in temperature</li><li>confusion</li><li>aggression</li><li>convulsions</li><li>loss of consciousness</li></ul><p>If you have these symptoms during a heatwave, rest for a few hours, keep cool and drink water. If the symptoms don&rsquo;t go away or get worse, seek medical advice. Heatstroke can kill. It can develop very suddenly and may lead very quickly to unconsciousness. If you suspect someone has heatstroke, call 999 immediately. While waiting for the ambulance:</p><ul><li>move the person somewhere cooler if possible</li><li>increase ventilation by opening windows or using a fan</li><li>cool them down as quickly as possible by loosening their clothes, sprinkling them with cold water or wrapping them in a damp sheet</li><li>if they are conscious, give them water to drink</li><li>don&#39;t give them aspirin or paracetamol</li></ul><p><strong><span style=\"font-size: 24px;\">People at risk during hot weather</span></strong></p><p>Heat can affect anyone, but some people are at greater risk of serious harm from the effects of extreme heat. These include:</p><ul><li>older people, especially those over 75 years of age</li><li>babies and young children</li><li>people with mental health problems</li><li>people on certain types of medication &ndash; ask your doctor if you are at risk</li><li>people with a chronic health condition such as breathing or heart problems</li><li>people who already have a high temperature from an infection</li><li>people who misuse alcohol or use illegal drugs</li><li>people with mobility problems</li><li>people who are physically active such as manual workers or sportspeople</li></ul><p>If anyone you know is likely to be at risk during a heatwave, help them to get the advice and support they need. Older people living on their own should be visited daily to check they are well.</p><p><strong><span style=\"font-size: 24px;\"><br></span></strong></p><p><strong><span style=\"font-size: 24px;\">What to do in hot weather</span></strong></p><p>You can take steps to protect yourself and others from the effects of very hot weather.</p><p>Check the weather forecast on our website so you know if a heatwave is on the way and plan ahead to reduce the risk of ill-health from the heat.</p><p><span style=\"font-size: 18px;\"><strong>Keep out of the heat</strong></span></p><ul><li>plan your day so that you can stay out of the heat when possible</li><li>try to stay out of the sun, particularly when it is at its highest between 11.00 am and 3.00 pm</li><li>do strenuous outdoor activities, like sports, DIY or gardening during cooler parts of the day</li><li>stock up on supplies like medicines, food and non-alcoholic drinks, so you won&rsquo;t have to go out in the heat</li><li>if you must go out, stay in the shade and wear a hat and loose-fitting cotton clothes</li><li>use a sun cream with a high sun protection factor - also known as &#39;SPF&#39; - for protection from the sun&#39;s harmful ultraviolet (UV) radiation - &nbsp;SPF 15 or greater is advised with a UVA Rating of at least 4 stars (external link opens in a new window / tab)&nbsp;</li><li>don&#39;t leave babies or children in a parked car</li></ul><p><strong><span style=\"font-size: 18px;\">Keep you and your house cool</span></strong></p><p>In hot weather, stay inside the coolest rooms in your house as much as possible. These are probably the rooms that get little sun during the day. To help keep all rooms in your house cool, you can:</p><ul><li>close pale-coloured curtains</li><li>take care with metal blinds and dark curtains as they absorb heat - consider replacing them or putting reflective material in between them and the window</li><li>keep windows closed when it&rsquo;s hotter outside than inside, but open them if the room gets too hot</li><li>open windows at night when the air is cooler, but close ground floor windows when you leave the house or go to bed</li><li>place a thermometer in your main living room and bedroom to keep a check on the temperature</li><li>turn off non-essential lights and electrical equipment - they generate heat</li><li>keep indoor plants and bowls of water in the house as evaporation helps keep cool the air</li><li>take cool showers or baths and splash yourself several times a day with cold water, especially your face and the back of your neck</li></ul><p><strong><span style=\"font-size: 18px;\">Drink plenty</span></strong></p><ul><li>drink regularly even if you do not feel thirsty &ndash; water or fruit juice are best</li><li>try to avoid alcohol, tea and coffee as these can cause dehydration</li><li>avoid heavy and hot food; fruit and salads can help keep you hydrated</li></ul><p><span style=\"font-size: 18px;\">Take extra care with food in hot weather</span></p><p>When it&rsquo;s hot, bacteria on food can multiply very quickly, which increases the risk of food poisoning.</p><p><strong><span style=\"font-size: 18px;\">Take care with bins and waste</span></strong></p><ul><li>Bins and waste can attract flies and start to smell in the heat, so make sure you:</li><li>recycle as much as possible to reduce waste</li><li>move bins out of direct sunlight and keep their lids closed at all times to prevent access by flies or rodents</li><li>use bio-degradable bags recommended by your council for food waste and squeeze the air out of the top of the bags before you tie them then place them in your food waste or garden waste bin</li><li>bag nappies before placing in your waste bin</li><li>wash and/ or disinfect waste containers regularly, both inside and out but remember to rinse off any cleaning chemicals afterwards to prevent yourself or council workers being splashed by the chemicals</li></ul><p><span style=\"font-size: 18px;\">Looking after pets</span></p><p>You must also take care of pets and other animals during warm weather. Make sure they have plenty of ventilation and liquid to stay hydrated.</p><p><strong>Never</strong> leave animals inside a car on a hot day and make sure they have:</p><ul><li>plenty of clean, fresh water to drink</li><li>a cool and shady place to rest</li></ul><p>It&rsquo;s also important to cover pet food dishes to prevent flies laying eggs on the food. Contact a vet if you are worried that an animal is suffering from heatstroke.</p><p><br></p>'),
(8, 'Cold Weather Advice ', '<p><strong>Placeholder Text</strong></p>'),
(9, 'Keep Safe in Areas with low air quality', '<p><strong>Placeholder Text</strong></p>'),
(10, 'Advice for keeping safe in Snow', '<p><strong>Placeholder Text</strong></p>'),
(11, 'Advice for keeping safe in Rain', '<p><strong>Placeholder Text</strong></p>'),
(12, 'Advice for keeping safe in Fog', '<p><strong>Placeholder Text</strong></p>'),
(14, 'Thunderstorms: How to keep safe', '<p><strong>Placeholder Text</strong></p>'),
(15, 'Tornados: How to keep safe', '<p><strong>Placeholder Text</strong></p>'),
(17, 'Atmospheric Pressure and how it affects our health', '<p><strong>Placeholder Text</strong></p>');

-- --------------------------------------------------------

--
-- Table structure for table `healthtracker`
--

CREATE TABLE `healthtracker` (
  `UserWeight` float DEFAULT NULL,
  `UserTimeSleeping` float DEFAULT NULL,
  `UserHeight` float DEFAULT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `healthtracker`
--

INSERT INTO `healthtracker` (`UserWeight`, `UserTimeSleeping`, `UserHeight`, `UserID`) VALUES
(113, NULL, 0, 5),
(80.5, 8, 1.87, 6),
(NULL, NULL, NULL, 9),
(NULL, NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Email` varchar(320) NOT NULL,
  `HashedUserPassword` varchar(60) NOT NULL,
  `Username` varchar(25) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `FirstName`, `LastName`, `Email`, `HashedUserPassword`, `Username`, `Title`) VALUES
(5, 'Gurtis', 'Clinton', 'GClinton@askjeeves.com', '$2y$10$IMhy0stzHOVcwIELNsTwReOryVVpgBhqOVsUlWV4w8GJgUJIxpRRa', NULL, NULL),
(6, 'Doctor', 'Amigo', 'Dram1go@askjeeves.com', '$2y$10$IMhy0stzHOVcwIELNsTwReOryVVpgBhqOVsUlWV4w8GJgUJIxpRRa', 'DAmigo50', 'Developer'),
(9, 'Grant', 'Vincent ', 'GVincent1st@askjeeves.com', '$2y$10$0SezaY034.r46XPauT5E2OoQeyMGiUTjbvs7P/GpTvBQ.AWmRxaa.', '1l0vefroy0_60', 'Tester'),
(10, 'John', 'Keys', 'Jkeys93@askjeeves.com', '$2y$10$F/qonPutJri45bR4FXdEVek6pY7ZhIv7BtQHQkv2y1jCSekgMMmtG', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `healthtracker`
--
ALTER TABLE `healthtracker`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `healthtracker`
--
ALTER TABLE `healthtracker`
  ADD CONSTRAINT `UserHealthTracker` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
